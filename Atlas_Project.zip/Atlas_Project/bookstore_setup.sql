
-- ==========================================
-- Create database and user
-- ==========================================
CREATE DATABASE IF NOT EXISTS bookstore;
USE bookstore;

CREATE USER IF NOT EXISTS 'app'@'localhost' IDENTIFIED BY 'app';
GRANT ALL PRIVILEGES ON bookstore.* TO 'app'@'localhost';
FLUSH PRIVILEGES;

-- ==========================================
-- Schema
-- ==========================================

CREATE TABLE IF NOT EXISTS users (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  username VARCHAR(100) UNIQUE NOT NULL,
  email VARCHAR(255) UNIQUE NOT NULL,
  password_hash VARCHAR(255) NOT NULL
);

CREATE TABLE IF NOT EXISTS books (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  title VARCHAR(255) NOT NULL,
  author VARCHAR(255) NOT NULL,
  isbn VARCHAR(20) UNIQUE NOT NULL,
  price DECIMAL(10,2) NOT NULL,
  description TEXT
);

-- Indexes for faster search
CREATE INDEX idx_books_title ON books(title);
CREATE INDEX idx_books_author ON books(author);

CREATE TABLE IF NOT EXISTS orders (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  user_id BIGINT NOT NULL,
  total DECIMAL(10,2) NOT NULL,
  created_at DATETIME NOT NULL,
  CONSTRAINT fk_orders_user FOREIGN KEY (user_id) REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS order_items (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  order_id BIGINT NOT NULL,
  book_id BIGINT NOT NULL,
  quantity INT NOT NULL,
  price DECIMAL(10,2) NOT NULL,
  CONSTRAINT fk_items_order FOREIGN KEY (order_id) REFERENCES orders(id),
  CONSTRAINT fk_items_book FOREIGN KEY (book_id) REFERENCES books(id)
);

-- ==========================================
-- Sample Data
-- ==========================================

-- Users
INSERT INTO users (username, email, password_hash) VALUES
('alice','alice@example.com','hash1'),
('bob','bob@example.com','hash2');

-- Books
INSERT INTO books (title, author, isbn, price, description) VALUES
('Clean Code','Robert C. Martin','9780132350884', 450.00, 'A Handbook of Agile Software Craftsmanship'),
('Design Patterns','Erich Gamma et al.','9780201633610', 550.00, 'Elements of Reusable Object-Oriented Software');


