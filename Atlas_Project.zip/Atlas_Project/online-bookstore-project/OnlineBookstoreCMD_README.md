# Online Bookstore - Command Reference

This file lists all the **important Maven, Spring Boot, and MySQL commands** you need to build, run, and fix common issues in the project.

---

## 1. Run the Application

Run Spring Boot while skipping tests (recommended for quick startup):
```bash
mvn spring-boot:run -Dmaven.test.skip=true
```

Run with tests enabled:
```bash
mvn spring-boot:run
```

---

## 2. Build and Rebuild the Project

Clean old builds and package the project:
```bash
mvn clean package -Dmaven.test.skip=true
```

Clean, compile, and install dependencies:
```bash
mvn clean install -U
```

Delete previous compiled files and rebuild:
```bash
mvn clean
mvn package
```

---

## 3. Dependency & Cache Fixes

Force Maven to re-download all dependencies:
```bash
mvn dependency:purge-local-repository
mvn clean install
```

If still broken, delete the `.m2/repository` folder manually and run:
```bash
mvn clean install -U
```

---

## 4. MySQL Commands

Login to MySQL:
```bash
mysql -u root -p
```

Create database and user (if not done):
```sql
CREATE DATABASE bookstore;
CREATE USER 'app'@'localhost' IDENTIFIED BY 'app';
GRANT ALL PRIVILEGES ON bookstore.* TO 'app'@'localhost';
FLUSH PRIVILEGES;
```

Show databases:
```sql
SHOW DATABASES;
USE bookstore;
SHOW TABLES;
```

View data:
```sql
SELECT * FROM users;
SELECT * FROM books;
SELECT * FROM orders;
SELECT * FROM order_items;
```

---

## 5. Restarting the Server

Stop currently running Spring Boot app:
- In terminal: `Ctrl + C`

Restart again:
```bash
mvn spring-boot:run -Dmaven.test.skip=true
```

---

## 6. Common Error Fix Commands

| Problem | Fix |
|----------|------|
| Port 8080 already in use | `netstat -ano | findstr :8080` → `taskkill /PID <pid> /F` |
| “Failed to determine a suitable driver class” | Check `application.properties` for DB config |
| “No plugin found for prefix spring-boot” | Add `<version>3.3.2</version>` under `spring-boot-maven-plugin` in `pom.xml` |
| “BUILD FAILURE: Compilation error” | Run `mvn clean package -Dmaven.test.skip=true` |
| “Tests failing” | Skip tests → `-Dmaven.test.skip=true` |
| “Cannot connect to database” | Ensure MySQL server is running & credentials match |

---

## 7. Full Clean Reset (Last Resort)

Use these if everything breaks or dependency errors persist:
```bash
mvn dependency:purge-local-repository
mvn clean install -U
mvn spring-boot:run -Dmaven.test.skip=true
```

---

## 8. Swagger API URL

After app starts:
[http://localhost:8080/swagger-ui.html](http://localhost:8080/swagger-ui.html)

---

## 9. Quick Run Checklist

1. MySQL server is **running**
2. Database **bookstore** exists
3. `application.properties` has correct credentials:
   ```
   spring.datasource.url=jdbc:mysql://localhost:3306/bookstore
   spring.datasource.username=app
   spring.datasource.password=app
   ```
4. Then execute:
   ```bash
   mvn clean package -Dmaven.test.skip=true
   mvn spring-boot:run -Dmaven.test.skip=true
   ```

---

## Author

**Developer:** Thanmy Mydam  
**Purpose:** Internal Project Command Reference  
**Trainer Use:** Review commands and run sequence easily
