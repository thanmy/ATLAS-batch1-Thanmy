# Day-wise Submission Checklist

## Day 1 – Requirement Gathering
- Submit: Day1_Requirement_Specification.pdf

## Day 2 – OOAD & Design
- Submit: diagrams/class-diagram.mmd, diagrams/usecase-diagram.mmd, diagrams/er-diagram.mmd (export as PNG/PDF if needed)

## Day 3 – Environment Setup
- Submit: Screenshot of app starting and printing "Hello Bookstore"

## Day 4 – Implement Book Search
- Submit: BookService.java, SQL schema/data, demo screenshot of search

## Day 5 – Cart & Checkout
- Submit: Cart.java, CheckoutController.java/CheckoutService.java, DB order table screenshot

## Day 6 – DynamoDB Integration
- Submit: RecommendationService.java, demo screenshot of /api/recommendations/{username}

## Day 7 – Data Structures
- Submit: BrowsingHistory.java, demo screenshot of /api/history/{username}

## Day 8 – BDD Scenarios
- Submit: SearchBook.feature, SearchBookSteps.java, test report screenshot

## Day 9 – DevOps Setup
- Submit: Git repo link and Jenkins Pipeline success screenshot

## Day 10 – Deployment & Demo
- Submit: Report (PDF), live demo screenshots/video
