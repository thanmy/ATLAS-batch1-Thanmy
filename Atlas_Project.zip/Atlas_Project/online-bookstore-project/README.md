# Online Bookstore (Java 17, Spring Boot, MySQL, DynamoDB, Cucumber, Jenkins)

## Quickstart
```bash
docker compose up -d   # start MySQL & DynamoDB Local
cp src/main/resources/application.properties.example src/main/resources/application.properties
mvn spring-boot:run
# Swagger UI: http://localhost:8080/swagger-ui/index.html
```

## Endpoints
- `GET /api/books?title=Clean` (search)
- `POST /api/cart/{username}/add?bookId=1&qty=2`
- `GET /api/cart/{username}`
- `POST /api/checkout/{username}`
- `GET /api/recommendations/{username}`
- `GET /api/history/{username}`

## Day-wise Deliverables
See `/docs/daywise.md` and `/diagrams/*.mmd` plus `/sql/*.sql`.
