package com.example.bookstore.repo;

import com.example.bookstore.domain.Book;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import java.util.List;

public interface BookRepository extends JpaRepository<Book, Long> {
  List<Book> findByTitleContainingIgnoreCase(String title);
  List<Book> findByAuthorContainingIgnoreCase(String author);

  @Query("""
select b from Book b where lower(b.title) like lower(concat('%', :q, '%'))
   or lower(b.author) like lower(concat('%', :q, '%'))
   or lower(b.isbn) like lower(concat('%', :q, '%'))
""")
  List<Book> search(String q);
}
