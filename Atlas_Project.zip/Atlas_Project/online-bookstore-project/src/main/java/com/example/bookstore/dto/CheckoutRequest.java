package com.example.bookstore.dto;

import java.util.Map;
// key=bookId, value=qty
public record CheckoutRequest(Map<Long,Integer> items) {}
