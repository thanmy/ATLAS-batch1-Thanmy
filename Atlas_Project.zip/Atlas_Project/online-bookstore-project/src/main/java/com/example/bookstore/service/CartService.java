package com.example.bookstore.service;

import com.example.bookstore.domain.Cart;
import com.example.bookstore.domain.BrowsingHistory;
import org.springframework.stereotype.Service;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Service
public class CartService {
  private final Map<String, Cart> carts = new ConcurrentHashMap<>();
  private final Map<String, BrowsingHistory> histories = new ConcurrentHashMap<>();

  public Cart cartFor(String username){
    return carts.computeIfAbsent(username, k -> new Cart());
  }
  public BrowsingHistory historyFor(String username){
    return histories.computeIfAbsent(username, k -> new BrowsingHistory(10));
  }
}
