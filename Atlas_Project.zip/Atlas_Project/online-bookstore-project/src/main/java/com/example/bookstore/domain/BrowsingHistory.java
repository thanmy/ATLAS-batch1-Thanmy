package com.example.bookstore.domain;

import java.util.LinkedList;
import java.util.List;

public class BrowsingHistory {
  private final LinkedList<Long> recent = new LinkedList<>();
  private final int limit;
  public BrowsingHistory(int limit){ this.limit = limit; }

  public void viewed(Long bookId){
    recent.remove(bookId);
    recent.addFirst(bookId);
    if(recent.size() > limit) recent.removeLast();
  }
  public List<Long> getRecent(){ return java.util.List.copyOf(recent); }
}
