package com.example.bookstore.web;

import com.example.bookstore.domain.Cart;
import com.example.bookstore.service.BookService;
import com.example.bookstore.service.CartService;
import org.springframework.web.bind.annotation.*;
import java.math.BigDecimal;

@RestController
@RequestMapping("/api/cart")
public class CartController {
  private final CartService carts;
  private final BookService books;
  public CartController(CartService carts, BookService books){ this.carts = carts; this.books = books; }

  @PostMapping("/{username}/add")
  public Cart add(@PathVariable String username, @RequestParam Long bookId, @RequestParam int qty){
    var cart = carts.cartFor(username);
    cart.addBook(bookId, qty);
    return cart;
  }

  @PostMapping("/{username}/remove")
  public Cart remove(@PathVariable String username, @RequestParam Long bookId){
    var cart = carts.cartFor(username);
    cart.removeBook(bookId);
    return cart;
  }

  @GetMapping("/{username}")
  public java.util.Map<String,Object> view(@PathVariable String username){
    var cart = carts.cartFor(username);
    BigDecimal total = cart.calculateTotal(id -> books.get(id).getPrice());
    return java.util.Map.of("items", cart.getItems(), "total", total);
  }
}
