package com.example.bookstore.domain;

import jakarta.persistence.*;
import java.math.BigDecimal;
import lombok.*;

@Entity @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
@Table(name = "books")
public class Book {
  @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;
  private String title;
  private String author;
  @Column(unique = true)
  private String isbn;
  private BigDecimal price;
  @Column(columnDefinition = "TEXT")
  private String description;
}
