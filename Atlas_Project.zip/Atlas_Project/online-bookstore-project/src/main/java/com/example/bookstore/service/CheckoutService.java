package com.example.bookstore.service;

import com.example.bookstore.domain.*;
import com.example.bookstore.repo.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Map;

@Service
public class CheckoutService {
  private final UserRepository users;
  private final BookRepository books;
  private final OrderRepository orders;
  private final OrderItemRepository items;

  public CheckoutService(UserRepository users, BookRepository books, OrderRepository orders, OrderItemRepository items){
    this.users = users; this.books = books; this.orders = orders; this.items = items;
  }

  @Transactional
  public Order checkout(String username, Map<Long,Integer> cartItems){
    var user = users.findByUsername(username).orElseThrow();
    var order = Order.builder().user(user).total(BigDecimal.ZERO).createdAt(LocalDateTime.now()).build();
    order = orders.save(order);
    BigDecimal total = BigDecimal.ZERO;
    for(var e: cartItems.entrySet()){
      var book = books.findById(e.getKey()).orElseThrow();
      var qty = Math.max(e.getValue(), 1);
      var price = book.getPrice();
      var item = OrderItem.builder().order(order).book(book).quantity(qty).price(price).build();
      items.save(item);
      total = total.add(price.multiply(BigDecimal.valueOf(qty)));
    }
    order.setTotal(total);
    return orders.save(order);
  }
}
