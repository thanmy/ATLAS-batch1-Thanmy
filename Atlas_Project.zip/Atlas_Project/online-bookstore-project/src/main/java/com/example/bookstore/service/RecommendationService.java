package com.example.bookstore.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import software.amazon.awssdk.auth.credentials.AwsBasicCredentials;
import software.amazon.awssdk.auth.credentials.StaticCredentialsProvider;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.dynamodb.DynamoDbClient;
import software.amazon.awssdk.services.dynamodb.model.*;

import java.net.URI;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class RecommendationService {
  private final DynamoDbClient client;
  @Value("${recommendations.table:RecommendedBooks}") String tableName;

  public RecommendationService(
      @Value("${AWS_ACCESS_KEY_ID:test}") String key,
      @Value("${AWS_SECRET_ACCESS_KEY:test}") String secret,
      @Value("${AWS_REGION:us-east-1}") String region,
      @Value("${DYNAMO_ENDPOINT:http://localhost:8000}") String endpoint
  ){
    this.client = DynamoDbClient.builder()
      .credentialsProvider(StaticCredentialsProvider.create(AwsBasicCredentials.create(key, secret)))
      .region(Region.of(region))
      .endpointOverride(URI.create(endpoint))
      .build();
  }

  public List<String> top5ForUser(String username){
    var resp = client.query(q -> q
      .tableName(tableName)
      .keyConditionExpression("username = :u")
      .expressionAttributeValues(java.util.Map.of(":u", AttributeValue.builder().s(username).build()))
      .limit(5));
    return resp.items().stream()
      .map(m -> m.getOrDefault("bookTitle", AttributeValue.fromS("Unknown")).s())
      .collect(Collectors.toList());
  }
}
