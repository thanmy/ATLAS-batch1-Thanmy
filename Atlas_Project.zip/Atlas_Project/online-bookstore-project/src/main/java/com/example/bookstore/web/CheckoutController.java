package com.example.bookstore.web;

import com.example.bookstore.dto.CheckoutRequest;
import com.example.bookstore.domain.Order;
import com.example.bookstore.service.CheckoutService;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/checkout")
public class CheckoutController {
  private final CheckoutService checkout;
  public CheckoutController(CheckoutService checkout){ this.checkout = checkout; }

  @PostMapping("/{username}")
  public Order place(@PathVariable String username, @RequestBody CheckoutRequest req){
    return checkout.checkout(username, req.items());
  }
}
