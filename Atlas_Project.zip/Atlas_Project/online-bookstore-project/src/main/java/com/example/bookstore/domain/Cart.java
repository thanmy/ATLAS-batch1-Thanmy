package com.example.bookstore.domain;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

public class Cart {
  // key=bookId, value=qty
  private final Map<Long, Integer> items = new HashMap<>();

  public void addBook(Long bookId, int qty){
    items.merge(bookId, Math.max(qty,1), Integer::sum);
  }
  public void removeBook(Long bookId){
    items.remove(bookId);
  }
  public Map<Long,Integer> getItems(){ return items; }

  public BigDecimal calculateTotal(java.util.function.Function<Long, BigDecimal> priceProvider){
    return items.entrySet().stream()
      .map(e -> priceProvider.apply(e.getKey()).multiply(BigDecimal.valueOf(e.getValue())))
      .reduce(BigDecimal.ZERO, BigDecimal::add);
  }
}
