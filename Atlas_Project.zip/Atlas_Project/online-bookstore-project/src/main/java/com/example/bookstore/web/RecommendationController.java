package com.example.bookstore.web;

import com.example.bookstore.service.RecommendationService;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/recommendations")
public class RecommendationController {
  private final RecommendationService recos;
  public RecommendationController(RecommendationService recos){ this.recos = recos; }

  @GetMapping("/{username}")
  public List<String> top(@PathVariable String username){
    return recos.top5ForUser(username);
  }
}
