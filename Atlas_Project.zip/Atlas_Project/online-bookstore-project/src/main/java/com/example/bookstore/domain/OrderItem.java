package com.example.bookstore.domain;

import jakarta.persistence.*;
import java.math.BigDecimal;
import lombok.*;

@Entity @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
@Table(name = "order_items")
public class OrderItem {
  @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;

  @ManyToOne(optional = false)
  private Order order;

  @ManyToOne(optional = false)
  private Book book;

  private int quantity;
  private BigDecimal price;
}
