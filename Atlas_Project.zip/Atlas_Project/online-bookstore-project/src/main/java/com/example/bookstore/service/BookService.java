package com.example.bookstore.service;

import com.example.bookstore.domain.Book;
import com.example.bookstore.repo.BookRepository;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class BookService {
  private final BookRepository repo;
  public BookService(BookRepository repo){ this.repo = repo; }

  public Book create(Book b){ return repo.save(b); }
  public List<Book> all(){ return repo.findAll(); }
  public List<Book> search(String q){
    if(q==null || q.isBlank()) return all();
    return repo.search(q.trim());
  }
  public Book get(Long id){ return repo.findById(id).orElseThrow(); }
}
