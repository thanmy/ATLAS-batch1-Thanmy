package com.example.bookstore.web;

import com.example.bookstore.service.CartService;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/history")
public class HistoryController {
  private final CartService carts;
  public HistoryController(CartService carts){ this.carts = carts; }

  @GetMapping("/{username}")
  public List<Long> recent(@PathVariable String username){
    return carts.historyFor(username).getRecent();
  }
}
