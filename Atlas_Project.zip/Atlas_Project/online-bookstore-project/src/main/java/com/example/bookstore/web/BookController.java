package com.example.bookstore.web;

import com.example.bookstore.domain.Book;
import com.example.bookstore.service.BookService;
import com.example.bookstore.service.CartService;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/books")
public class BookController {
  private final BookService service;
  private final CartService carts;
  public BookController(BookService service, CartService carts){ this.service = service; this.carts = carts; }

  @GetMapping
  public List<Book> search(@RequestParam(value="q", required=false) String q){
    return service.search(q);
  }

  @GetMapping("/{id}")
  public Book get(@PathVariable Long id, @RequestParam String username){
    var b = service.get(id);
    carts.historyFor(username).viewed(id);
    return b;
  }

  @PostMapping
  public Book create(@RequestBody Book b){ return service.create(b); }
}
