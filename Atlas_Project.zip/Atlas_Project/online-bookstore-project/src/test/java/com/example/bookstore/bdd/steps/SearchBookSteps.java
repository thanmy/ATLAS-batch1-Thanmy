package com.example.bookstore.bdd.steps;

import com.example.bookstore.domain.Book;
import com.example.bookstore.repo.BookRepository;
import com.example.bookstore.service.BookService;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.assertj.core.api.Assertions;

import java.math.BigDecimal;
import java.util.List;

public class SearchBookSteps {
  private BookService service;

  @Given("the bookstore has {string}")
  public void the_bookstore_has(String title) {
    var repo = new BookRepository() {
      @Override public java.util.List<Book> findAll(){ 
        return java.util.List.of(Book.builder().id(1L).title(title).author("Robert C. Martin").isbn("9780132350884").price(new BigDecimal("450.00")).description("A Handbook").build()); 
      }
      // minimal anonymous impl for the test step:
      @Override public List<Book> findByTitleContainingIgnoreCase(String t){ return List.of(); }
      @Override public List<Book> findByAuthorContainingIgnoreCase(String a){ return List.of(); }
      @Override public List<Book> search(String q){ return findAll(); }
      @Override public <S extends Book> S save(S entity){ return entity; }
      @Override public java.util.Optional<Book> findById(Long aLong){ return java.util.Optional.empty(); }
      @Override public void deleteById(Long aLong){}
      @Override public void delete(Book entity){}
      @Override public long count(){ return 1; }
      @Override public boolean existsById(Long aLong){ return true; }
      @Override public List<Book> findAllById(Iterable<Long> longs){ return List.of(); }
      @Override public <S extends Book> List<S> saveAll(Iterable<S> entities){ return List.of(); }
      @Override public void flush(){}
      @Override public <S extends Book> S saveAndFlush(S entity){ return entity; }
      @Override public void deleteAllInBatch(Iterable<Book> entities){}
      @Override public void deleteAllByIdInBatch(Iterable<Long> longs){}
      @Override public Book getOne(Long aLong){ return null; }
      @Override public Book getById(Long aLong){ return null; }
      @Override public <S extends Book> List<S> findAll(org.springframework.data.domain.Example<S> example){ return List.of(); }
      @Override public <S extends Book> List<S> findAll(org.springframework.data.domain.Example<S> example, org.springframework.data.domain.Sort sort){ return List.of(); }
      @Override public List<Book> findAll(org.springframework.data.domain.Sort sort){ return findAll(); }
      @Override public org.springframework.data.domain.Page<Book> findAll(org.springframework.data.domain.Pageable pageable){ return org.springframework.data.domain.Page.empty(); }
      @Override public <S extends Book> org.springframework.data.domain.Page<S> findAll(org.springframework.data.domain.Example<S> example, org.springframework.data.domain.Pageable pageable){ return org.springframework.data.domain.Page.empty(); }
      @Override public <S extends Book> long count(org.springframework.data.domain.Example<S> example){ return 1; }
      @Override public <S extends Book> boolean exists(org.springframework.data.domain.Example<S> example){ return true; }
      @Override public void deleteAll() {}
      @Override public <S extends Book> S insert(S entity){ return entity; }
      @Override public <S extends Book> List<S> insert(Iterable<S> entities){ return List.of(); }
    };
    service = new BookService(repo);
  }

  @When("the user searches for {string}")
  public void the_user_searches_for(String query) { }

  @Then("the system shows {string} with author name")
  public void the_system_shows_with_author_name(String expectedTitle) {
    var result = service.search(expectedTitle);
    Assertions.assertThat(result).extracting(Book::getTitle).contains(expectedTitle);
    Assertions.assertThat(result.get(0).getAuthor()).isNotBlank();
  }
}
