package com.example.bookstore.service;

import com.example.bookstore.domain.Book;
import com.example.bookstore.repo.BookRepository;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import java.util.List;
import static org.assertj.core.api.Assertions.assertThat;

public class BookServiceTests {
  @Test
  void searchFallsBackToAllWhenBlank(){
    var repo = Mockito.mock(BookRepository.class);
    Mockito.when(repo.findAll()).thenReturn(List.of(new Book()));
    var service = new BookService(repo);
    assertThat(service.search("")).hasSize(1);
  }
}
