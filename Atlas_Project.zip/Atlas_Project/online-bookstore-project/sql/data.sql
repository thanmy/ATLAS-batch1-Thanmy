INSERT INTO users (username, email, password_hash) VALUES
('alice','alice@example.com','hash1'),
('bob','bob@example.com','hash2');

INSERT INTO books (title, author, isbn, price, description) VALUES
('Clean Code','Robert C. Martin','9780132350884', 450.00, 'A Handbook of Agile Software Craftsmanship'),
('Design Patterns','Erich Gamma et al.','9780201633610', 550.00, 'Elements of Reusable Object-Oriented Software');
